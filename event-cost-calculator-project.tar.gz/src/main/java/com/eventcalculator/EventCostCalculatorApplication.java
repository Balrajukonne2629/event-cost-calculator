package com.eventcalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventCostCalculatorApplication {
    public static void main(String[] args) {
        SpringApplication.run(EventCostCalculatorApplication.class, args);
    }
}
